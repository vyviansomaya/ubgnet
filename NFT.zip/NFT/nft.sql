-- phpMyAdmin SQL Dump
-- version 5.1.0
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Jan 18, 2022 at 12:21 PM
-- Server version: 10.4.19-MariaDB
-- PHP Version: 8.0.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `nft`
--

-- --------------------------------------------------------

--
-- Table structure for table `politicians`
--

CREATE TABLE `politicians` (
  `id` int(11) NOT NULL,
  `name` varchar(250) DEFAULT NULL,
  `func` varchar(250) DEFAULT NULL,
  `desciption` text DEFAULT NULL,
  `photo` text DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `politicians`
--

INSERT INTO `politicians` (`id`, `name`, `func`, `desciption`, `photo`, `created_at`, `updated_at`) VALUES
(1, 'Armin Laschet', 'Vorsitzender der CDU Deutschlands', '1981 bis 1987 Studium der Rechts- und Staatswissenschaften in München und Bonn\r\n\r\n1987 1. Juristisches Staatsexamen vor dem Oberlandesgericht Köln\r\n\r\n1986 bis 1988 Ausbildung zum Journalisten\r\n\r\n1987 bis 1990 Freie journalistische Tätigkeit für bayerische Rundfunksender und das\r\n\r\nBayerische Fernsehen\r\n\r\n1988 bis 1993 Wissenschaftlicher Berater der Präsidentin des Deutschen Bundestages, Rita Süssmuth\r\n\r\n1991 bis 1999 Chefredakteur, Geschäftsführer und Verlagsleiter der Einhard-Verlags GmbH\r\n\r\n', 'laschet.jpg', '2022-01-19 00:55:14', '2022-01-19 00:55:14'),
(2, 'Julia Klöckner', 'Stv. Vorsitzende der CDU Deutschlands\r\n', '1992 Abitur am Gymnasium an der Stadtmauer in Bad Kreuznach\r\n\r\n1993 bis 1998 Studium der Politikwissenschaft, Theologie und Pädagogik mit dem Doppel-Studienabschluss Staatsexamen für Lehramt an Gymnasien und dem Magister an der Johannes Gutenberg-Universität Mainz\r\n\r\n1986 bis 1988 Ausbildung zum Journalisten\r\n\r\n1987 bis 1990 Freie journalistische Tätigkeit für bayerische Rundfunksender und das\r\n\r\nBayerische Fernsehen\r\n\r\n1988 bis 1993 Wissenschaftlicher Berater der Präsidentin des Deutschen Bundestages, Rita Süssmuth\r\n\r\n1991 bis 1999 Chefredakteur, Geschäftsführer und Verlagsleiter der Einhard-Verlags GmbH\r\n\r\nSeit 1999 Lehrbeauftragter des Europastudienganges der RWTH Aachen', 'kloeckner.jpg', '2022-01-18 00:57:10', '2022-01-19 00:57:10'),
(3, 'Angela Merkel\r\n', 'Mitglied im Präsidium\r\n', '1992 Abitur am Gymnasium an der Stadtmauer in Bad Kreuznach\r\n\r\n1993 bis 1998 Studium der Politikwissenschaft, Theologie und Pädagogik mit dem Doppel-Studienabschluss Staatsexamen für Lehramt an Gymnasien und dem Magister an der Johannes Gutenberg-Universität Mainz\r\n\r\n1986 bis 1988 Ausbildung zum Journalisten\r\n\r\n1987 bis 1990 Freie journalistische Tätigkeit für bayerische Rundfunksender und das\r\n\r\nBayerische Fernsehen\r\n\r\n1988 bis 1993 Wissenschaftlicher Berater der Präsidentin des Deutschen Bundestages, Rita Süssmuth\r\n\r\n1991 bis 1999 Chefredakteur, Geschäftsführer und Verlagsleiter der Einhard-Verlags GmbH\r\n\r\nSeit 1999 Lehrbeauftragter des Europastudienganges der RWTH Aachen', 'merkel.jpg', '2022-01-18 00:59:09', '2022-01-18 00:59:09'),
(4, 'Wolfgang Schäuble', 'Präsident des Deutschen Bundestages', 'Studium der Rechts- und Wirtschaftswissenschaften in Freiburg und Hamburg\r\n1966 Erstes juristisches Staatsexamen, danach Assistent an der Universität Freiburg und Beauftragter des Rektors für politische Bildung\r\n1970 Zweites juristisches Staatsexamen\r\n1971 Promotion und Eintritt in die Steuerverwaltung des Landes Baden-Württemberg\r\n1978 bis 1984 Zulassung als Rechtsanwalt beim Landgericht Offenburg\r\n', 'schaeuble.jpg', '2022-01-18 07:08:28', '2022-01-18 07:08:28'),
(5, 'Anette Widmann-Mauz', 'Mitglied des Bundesvorstandes', '\r\n1998 Mitglied des Deutschen Bundestags\r\n2000 bis 2005 Vorsitzende der Gruppe der Frauen\r\n2001 bis 2002 Beauftragte für Verbraucherschutz und Lebensmittelsicherheit\r\n2002 bis 2009 Gesundheitspolitische Sprecherin der CDU/CSU-Bundestagsfraktion\r\n2005 bis 2009 Vorsitzende der Arbeitsgruppe Gesundheit in der CDU/CSU-Bundestagsfraktion\r\n2008 Stellv. Vorsitzende des Bundesausschusses \"Arbeit und Soziales\" der CDU Deutschlands\r\n\r\n2009 bis 2018 Parlamentarische Staatssekretärin beim Bundesminister für Gesundheit\r\n\r\n2012 bis 2018 Mitglied im Bundesvorstand der CDU Deutschlands\r\n\r\nSeit 2015 Vorsitzende der Frauen Union \r\n?\r\nSeit 2018 Staatsministerin bei der Bundeskanzlerin und Beauftragte der Bundesregierung für Migration, Flüchtlinge und Integration \r\n\r\nSeit Dezember 2018 Mitglied im Präsidium der CDU Deutschlands', 'widmann_mauz.jpg', '2022-01-18 07:19:58', '2022-01-18 07:19:58'),
(6, 'Paul Ziemiak', 'Mitglied des Bundesvorstandes', '1998 Eintritt in die Junge Union\r\n2001 Eintritt in die CDU\r\n2009 bis 2012 Vorsitzender des Bezirksverbands der JU Südwestfalen\r\n2011 bis 2019 Vorsitzender der CDU Iserlohn\r\n2012 bis 2014 Landesvorsitzender der JU NRW\r\n2014 bis 2019 Bundesvorsitzender der Jungen Union Deutschlands \r\n2014 bis 2019 Mitglied des Rates der Stadt Iserlohn\r\n2017 Mitglied der Bundesversammlung\r\nseit 2017 Mitglied des Deutschen Bundestags\r\nseit 2018 Generalsekretär der CDU Deutschlands ', 'ziemiak.jpg', '2022-01-18 07:19:58', '2022-01-18 07:19:58');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `politicians`
--
ALTER TABLE `politicians`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `politicians`
--
ALTER TABLE `politicians`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
