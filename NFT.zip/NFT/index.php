<?php include('db/config.php') ?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>PraktiKant-Probesite</title>
    <link rel="stylesheet" href="css/bootstrap.min.css" />
    <link rel="stylesheet" href="css/style.css" />
  </head>
  <body>
    <!--- Start Header Part --->
    <header>
      <nav class="navbar navbar-expand-lg">
        <div class="container">
          <a class="navbar-brand text-white" href="#">PraktiKant-Probesite</a>
          <button
            class="navbar-toggler"
            type="button"
            data-bs-toggle="collapse"
            data-bs-target="#navbarSupportedContent"
            aria-controls="navbarSupportedContent"
            aria-expanded="false"
            aria-label="Toggle navigation"
          >
            <span class="navbar-toggler-icon"></span>
          </button>
          <div
            class="collapse navbar-collapse"
            id="navbarSupportedContent"
          ></div>
        </div>
      </nav>
    </header>
    <!--- Start Header Part --->

    <!--- Sectiion Image Part --->
    <section>
      <div class="container pt-5">
        <div class="row pt-5">
          <?php 
          $sql = 'SELECT * FROM politicians';
          $retval = mysqli_query($conn, $sql );
                
          while($row = mysqli_fetch_array($retval)) {

          ?>
          <div class="col-lg-4 col-md-6 cl-sm-12 col-xs-12">
            <a href="armin.php?id=<?php echo $row['id'] ?>">
              <div class="card border-none">
                <img src="img/<?php echo $row['photo'] ?>" class="card-img-top" alt="..." />
                <div class="card-body">
                  <h3 class="card-title"><?php echo $row['name'] ?></h3>
                  <h5 class="card-text"><?php echo $row['func'] ?></h5>
                </div>
              </div>
            </a>
          </div>
          <?php } ?>
      </div>
    </section>
    <!--- Sectiion Image Part --->

    <!--- Footer Page Start --->
    <section>
      <div class="foter__section">
        <div class="container">
          <div class="row pt-3 pb-3">
            <div class="col-lg-4 col-md-4 col-sm-12 col-xs-12">
              <a href="" style="color: blue;">Datenschutz</a><br>
              <a href="" style="color: blue;">Impressum</a>
            </div>
          </div>
        </div>
      </div>
    </section>
    <!--- Footer Page Start --->

    <!--- Bootstrap JS File --->
    <script src="js/bootstrap.js"></script>
  </body>
</html>
